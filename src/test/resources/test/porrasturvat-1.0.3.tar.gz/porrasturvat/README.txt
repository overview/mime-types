
Porrasturvat - Stair Dismount
=============================

Copyright 2002-2005 Jetro Lauha

http://jet.ro/dismount/


Story
-----

    The legendary superhero Spector has found, to his shock, that he
    cannot write off all the damage he has caused to the city out of
    his taxes unless he proves that he has sustained significant
    damage in the process himself! Now it's up to you to 'help' him
    with this little detail..

Usage
-----
    1. Select the body part which you wish to push, by clicking on
       the damage diagram on the bottom left side of the screen.
    2. Depress left mouse button and drag sideways and up and down
       to select the angle of the push.
    3. Pay close attention to the pulsing power bar, and click on
       'dismount' when it shows the force that you wish to use for
       the push.


Contact
-------
    WWW	    http://jet.ro/dismount/

Hardware
--------
    Recommended minimum hardware:
	About 600 MHz processor
	Good OpenGL accelerated graphics adaptor
	Sound card
    Recommended hardware for good performance:
	1 GHz processor
	Fast OpenGL accelerated graphics adaptor (e.g. nVIDIA GeForce)
	High quality sound card

Keys
----
    Alt-Enter	Switch between window and fullscreen
    Space	Dismount / Reset
    Q		Select previous body part
    W		Select next body part
    R		Replay (when dismount is finished)
    P		Pause
    Ctrl-P	Step the time a little bit forward when paused
    C		Next camera viewpoint
    E		Reset pitch and heading
    S		Turn score view on/off
    M		Manual camera (hold the key)
    Ctrl-F	Enable/Disable fog (disabled by default, see notes)
    Ctrl-M	Turn music on/off
    Ctrl-S      Turn sound effects on/off
    0-9		Hotkeys for the camera viewpoints
    Arrow keys	Finetune heading & pitch (see notes)
    Escape	Quit the game

Notes
-----
    * Hold shift for even finer grain when finetuning heading & pitch
      with arrow keys. Hold ctrl to adjust heading or pitch more at
      a time.
    * Manual camera controls:
	Drag with left button down: Change camera direction
	Drag with right button down: Change camera position (x & y)
	Drag with both buttons down: Change camera height (z)
    * Fog causes problems on some graphics cards so it's disabled by default.
    * All shown values are rounded from the exact value.



Credits
-------

Game Design & Lead Programmer:
	Jetro Lauha

Music:
	Simo Virokannas

Linux & MacOS X ports:
	Martin Storsj�



Additional Credits (from the original release of the game)
------------------
Programming etc.:
	tArzAn
Music:
	kArpo
Additional help:
	aSTrAaLIkaNisteri, eP�puhtAuSsaosTumA, keLmUharppU, LeIv�nkeITIN,
	miKROMIkko, tOiMISTokEiju, Wiba
Beta testers:
	diskoteekki, fragmentAAtio, hIlLOholIStI, KasvIuuTejUomA, lennart,
	LiITerI, paparazzi, RallivAIhDE, roskAROMAani, TBB, vEiVi, Zarniwoop


See the Porrasturvat Live video:
	http://taat.fi/taat/files/porrasturvat_live.avi

==============================================================================
	
Acknowledgements:

==============================================================================
Special thanks to Nate Waddoups.
==============================================================================
This program uses the SDL and SDL_image libraries. http://www.libsdl.org
==============================================================================
FMOD library Copyright � Firelight Technologies, Pty, Ltd. 1994-2005
==============================================================================
zlib compression library Copyright 1995-2002 Jean-loup Gailly and Mark Adler
==============================================================================
CFL library Copyright (c) 2001 Jari Komppa
==============================================================================
This program uses the libpng image library.
Copyright (c) 1998-2000 Glenn Randers-Pehrson
Copyright (c) 1996, 1997 Andreas Dilger
Copyright (c) 1995, 1996 Guy Eric Schalnat, Group 42, Inc.
==============================================================================
This software is based in part on the work of the Independent JPEG Group.
==============================================================================
Open Dynamics Engine (ODE) library license:

This is the BSD-style license for the Open Dynamics Engine
----------------------------------------------------------

Open Dynamics Engine
Copyright (c) 2001-2003, Russell L. Smith.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

Neither the names of ODE's copyright owner nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
==============================================================================
libcurl license:

COPYRIGHT AND PERMISSION NOTICE

Copyright (c) 1996 - 2003, Daniel Stenberg, <daniel@haxx.se>.

All rights reserved.

Permission to use, copy, modify, and distribute this software for any purpose
with or without fee is hereby granted, provided that the above copyright
notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of a copyright holder shall not
be used in advertising or otherwise to promote the sale, use or other dealings
in this Software without prior written authorization of the copyright holder.
==============================================================================
expat library license:

Copyright (c) 1998, 1999, 2000 Thai Open Source Software Center Ltd
                               and Clark Cooper
Copyright (c) 2001, 2002 Expat maintainers.

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
==============================================================================
